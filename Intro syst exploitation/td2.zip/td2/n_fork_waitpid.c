#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <errno.h>
#include <sys/wait.h>

int main (int argc, char * argv[]) {
    pid_t pid;
    int fils;
    int NB_FILS = atoi(argv[1]);

    for (fils = 0; fils < NB_FILS; fils ++) {
        if ((pid = fork()) < 0) {
            perror("fork");
            exit(EXIT_FAILURE);
        }
        if (pid != 0) continue;
        printf("Je suis le fils %d (%d) du père %d\n", fils, getpid(), getppid());
        exit(EXIT_SUCCESS);
    }

    int w, retour;

    while((w = wait(&retour))>0){
        printf("Le fils (%d) a termine avec le code retour %d\n", w, WEXITSTATUS(retour));
    }

    while (wait(NULL) > 0)
        printf("...\n");
    exit(EXIT_SUCCESS);
}