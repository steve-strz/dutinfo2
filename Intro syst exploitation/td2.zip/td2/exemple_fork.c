#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <errno.h>
#include <sys/wait.h>

int main(int argc, char*argv []) {
    pid_t pid_fils = fork();

    if (pid_fils == -1) {
        fprintf(stderr, "fork() impossible, errno=%d\n", errno);
        return EXIT_FAILURE;
    }
    if (pid_fils == 0) {
        /* processus fils */
        fprintf(stdout, "Fils : CdC=%s PID=%ld, PPID=%ld\n", argv[1] ,(long) getpid(), (long) getppid());
        sleep(5); // sinon le fils peut terminer avant le début du père
        return EXIT_SUCCESS;
    }else { 
        // pid_fils contient le PID du processus créé par fork()
        /* processus père */
        fprintf(stdout, "Père : CdC=%s PID=%ld, PPID=%ld, PID fils=%ld\n", argv[2] ,(long) getpid(), (long) getppid(),
        (long) pid_fils);
        wait(NULL); // on attend le premier fils qui termine
        return EXIT_SUCCESS;
    }
}