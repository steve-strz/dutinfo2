#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <errno.h>
#include <sys/wait.h>

int main(int argc, char *argv[]){
    pid_t pid_fils = fork();
    if(pid_fils == -1){
        fprintf(stderr, "fork() impossible errno==%d\n", errno);
        return EXIT_FAILURE;
    }
    if(pid_fils == 0){
        fprintf(stdout, "Fils : PID=%ld, PPID=%ld\n", (long)getpid(), (long)getppid());
        sleep(5);
        return EXIT_SUCCESS;
    }else{
        fprintf(stdout, "Père : PID=%ld, PPID=%ld, PID fils=%ld\n", (long) getpid(), (long) getppid(),(long) pid_fils);
        wait(NULL);
        return EXIT_SUCCESS;    
    }
}
