#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>

int main(int argc, char *argv[]){
    int res = fork();
    int t = atoi(argv[1]);
    printf("Résultat : %d, %d, %d\n", res, getpid(), getppid());
    sleep(t);
    return EXIT_SUCCESS;
}